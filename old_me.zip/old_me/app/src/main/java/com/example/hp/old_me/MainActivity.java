package com.example.hp.old_me;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    Button b1=(Button)findViewById(R.id.button);
    b1.setOnClickListener((new View.OnClickListener(){
        @Override
                public void onClick(View view)
        {
            Intent  intent=new Intent(getApplicationContext(),Main7Activity.class);
            startActivity(intent);
        }
    }));

        Button ba=(Button)findViewById(R.id.button15);
        ba.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent  intent=new Intent(getApplicationContext(),Main13Activity.class);
                startActivity(intent);
            }
        }));
    }

}
