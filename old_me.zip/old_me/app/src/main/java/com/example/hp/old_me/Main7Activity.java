package com.example.hp.old_me;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
public class Main7Activity extends AppCompatActivity {

    EditText Name, Dob, Add, Pat, Hosp, Pol;
    private com.example.hp.old_me.myDbAdapter helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
            Spinner spinner = (Spinner) findViewById(R.id.spinner2);
    // Create an ArrayAdapter using the string array and a default spinner layout
    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
            R.array.health_array, android.R.layout.simple_spinner_item);
    // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    Button bb = (Button) findViewById(R.id.button12);
    bb.setOnClickListener((new View.OnClickListener()

    {
        @Override
        public void onClick (View view)
        {
            Intent intent = new Intent(getApplicationContext(), Main8Activity.class);
            startActivity(intent);
        }
    }));
//        Name = (EditText) findViewById(R.id.editText16);
//        Dob = (EditText) findViewById(R.id.editText17);
//        Add = (EditText) findViewById(R.id.editText19);
////        Pat= (Spinner) findViewById(R.id.spinner2);
//        Hosp = (EditText) findViewById(R.id.editText21);
//        Pol = (EditText) findViewById(R.id.editText20);
//
//        helper = new com.example.hp.old_me.myDbAdapter(this);
//
//
//        public void addUser(View view) {
//            String t1 = Name.getText().toString();
//            String t2 = Dob.getText().toString();
//            if (t1.isEmpty() || t2.isEmpty()) {
//                com.example.hp.old_me.Message.message(getApplicationContext(), "Enter Both Name and Date of birth");
//            } else {
//                long id = helper.insertData(t1, t2);
//                if (id <= 0) {
//                    com.example.hp.old_me.Message.message(getApplicationContext(), "Insertion Unsuccessful");
//                    Name.setText("");
//                    Dob.setText("");
//                } else {
//                    com.example.hp.old_me.Message.message(getApplicationContext(), "Insertion Successful");
//                    Name.setText("");
//                    Dob.setText("");
//                }
//            }
//        }




    }
}
