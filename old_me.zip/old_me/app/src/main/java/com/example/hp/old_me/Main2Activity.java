package com.example.hp.old_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;


public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.month_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);



        Button b2=(Button)findViewById(R.id.button20);
        b2.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main3Activity.class);
                startActivity(intent);
            }
        }));
    }

    public void onButtonClick3(View v) {

        EditText t11 = (EditText) findViewById(R.id.editText);
        EditText t22 = (EditText) findViewById(R.id.editText3);
        EditText t33 = (EditText) findViewById(R.id.editText4);
        EditText t44 = (EditText) findViewById(R.id.editText5);
        EditText t55 = (EditText) findViewById(R.id.editText6);
        EditText t66 = (EditText) findViewById(R.id.editText7);



        int num1 = Integer.parseInt(t11.getText().toString());
        int num2 = Integer.parseInt(t22.getText().toString());
        int num3 = Integer.parseInt(t33.getText().toString());
        int num4 = Integer.parseInt(t44.getText().toString());
        int num5= Integer.parseInt(t55.getText().toString());
        int num6= Integer.parseInt(t66.getText().toString());


        int sum = num1 + num2 + num3 + num4+num5+num6;
        int per=sum/4;



        Toast.makeText(getApplicationContext(),"The total income is"+sum,Toast.LENGTH_SHORT).show();
    }

}
