package com.example.hp.old_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Button b3=(Button)findViewById(R.id.button8);
        b3.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main13Activity.class);
                startActivity(intent);
            }
        }));
    }

    public void onButtonClick(View v) {

        EditText t11 = (EditText) findViewById(R.id.editText8);
        EditText t22 = (EditText) findViewById(R.id.editText9);
        EditText t33 = (EditText) findViewById(R.id.editText10);
        EditText t44 = (EditText) findViewById(R.id.editText11);
        EditText t55 = (EditText) findViewById(R.id.editText12);



        int num1 = Integer.parseInt(t11.getText().toString());
        int num2 = Integer.parseInt(t22.getText().toString());
        int num3 = Integer.parseInt(t33.getText().toString());
        int num4 = Integer.parseInt(t44.getText().toString());
        int num5= Integer.parseInt(t55.getText().toString());

        int sum = num1 + num2 + num3 + num4+num5;
        int per=sum/4;



        Toast.makeText(getApplicationContext(),"The total expense is "+sum,Toast.LENGTH_SHORT).show();
    }

}

