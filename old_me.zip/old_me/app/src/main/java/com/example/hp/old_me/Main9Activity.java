package com.example.hp.old_me;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;



public class Main9Activity extends AppCompatActivity {


    ListView listone;
    String contacts[]={"Green bean casserole","Green papaya salad","Greek salad","Usthad Hotel","OK Kanmani"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listone =(ListView)findViewById(R.id.list1);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,contacts);
        listone.setAdapter(adapter);

        registerForContextMenu(listone);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu,v,menuInfo);
        menu.setHeaderTitle("Select One");
        menu.add(0,v.getId(),0,"Blockbuster");
        menu.add(0,v.getId(),0,"Super Hit");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        if(item.getTitle()=="Blockbuster")
        {
            Toast.makeText(getApplicationContext(),"Blockbuster Movie",Toast.LENGTH_LONG).show();
        }
        else if(item.getTitle()=="Super Hit")
        {
            Toast.makeText(getApplicationContext(),"Super Hit Movie",Toast.LENGTH_LONG).show();
        }
        else
        {
            return false;
        }
        return true;
    }
}
