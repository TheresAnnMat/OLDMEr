package com.example.hp.old_me;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main6Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        Button butmap = (Button) findViewById(R.id.button6);
        butmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strUri="http://maps.google.com/map?q=loc:" + 12.9360 + "," +77.6058 +" (" +"Christ University" + ")";
                Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(strUri));
                intent.setClassName("com.google.android.apps.maps","com.google.android.maps.MapsActivity");
                startActivity(intent);
            }     });


        Button butmap1 = (Button)findViewById(R.id.button7);
        butmap1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="https://www.olacabs.com/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        Button bbc=(Button)findViewById(R.id.button8);
        bbc.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main9Activity.class);
                startActivity(intent);
            }
        }));

        Button swiggy = (Button)findViewById(R.id.button9);
        swiggy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="https://www.swiggy.com/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        Button exp1=(Button)findViewById(R.id.button17);
        exp1.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main10Activity.class);
                startActivity(intent);
            }
        }));

        Button exp=(Button)findViewById(R.id.button16);
        exp.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(intent);
            }
        }));

        Button not=(Button)findViewById(R.id.button19);
        not.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main12Activity.class);
                startActivity(intent);
            }
        }));

        Button spar = (Button)findViewById(R.id.button10);
        spar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="https://sparindia.org.in/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });


        Button panic = (Button)findViewById(R.id.button11);
        panic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:9497031655"));
                intent.setData(Uri.parse("tel:9986715495"));
                intent.setData(Uri.parse("tel:9495744861"));
                intent.setData(Uri.parse("tel:9497031655"));
                intent.setData(Uri.parse("tel:9495744861"));

                Intent intent1=new Intent(Intent.ACTION_SENDTO,Uri.fromParts("mailto","theres.mathew@mca.christuniversity.in",null
                ));
                intent1.putExtra(Intent.EXTRA_SUBJECT,"Iam in emergency");
                intent1.putExtra(Intent.EXTRA_TEXT,"kkkkk ,kkkkk house,sgpalya,bangalore 78,phno:789456123");

                startActivity(Intent.createChooser(intent1,"Send mail"));

                startActivity(intent);

            }
        });




    }

}
