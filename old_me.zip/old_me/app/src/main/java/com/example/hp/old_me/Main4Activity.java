package com.example.hp.old_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);



        Button b5=(Button)findViewById(R.id.button5);
        b5.setOnClickListener((new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),Main13Activity.class);
                startActivity(intent);
            }
        }));
    }
}
